effect give @s minecraft:invisibility infinite 255 true
tag @s add controler
tag @e[tag=control] remove control
tag @e[type=!player,limit=1,sort=nearest] add control