effect clear @s minecraft:invisibility
tag @e[tag=control] remove control
tag @s remove controler