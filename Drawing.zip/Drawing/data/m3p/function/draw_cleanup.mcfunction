kill @e[type=minecraft:snowball,tag=m3p_drawing]
