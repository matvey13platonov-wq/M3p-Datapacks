execute as @a[scores={drawing=1}] at @s anchored eyes run summon minecraft:snowball ^ ^ ^4 {NoGravity:1b,Tags:["m3p_drawing"]}
